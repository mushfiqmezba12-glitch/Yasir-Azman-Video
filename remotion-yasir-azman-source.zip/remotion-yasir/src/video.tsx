import React from 'react';
import {AbsoluteFill, Audio, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
const scenes = [
 {start:0,end:90,title:'ইয়াসির আজমান',sub:'CEO • GRAMEENPHONE',tag:'A LEADER IN CONNECTIVITY'},
 {start:90,end:240,title:'ঢাকা বিশ্ববিদ্যালয় • IBA',sub:'শিক্ষা থেকে নেতৃত্বের ভিত্তি',tag:'EDUCATION / STRATEGY'},
 {start:240,end:450,title:'মাল্টিন্যাশনাল অভিজ্ঞতা',sub:'ধাপে ধাপে কর্পোরেট লিডারশিপ',tag:'GROWTH THROUGH EXPERIENCE'},
 {start:450,end:630,title:'লিডারশিপ • কমিউনিকেশন',sub:'স্ট্র্যাটেজিক থিংকিং',tag:'THE SKILLS BEHIND LEADERSHIP'},
 {start:630,end:780,title:'Chief Marketing Officer',sub:'গ্রামীণফোনে নেতৃত্বের নতুন ধাপ',tag:'CMO / BUSINESS IMPACT'},
 {start:780,end:900,title:'Deputy CEO',sub:'সিইও হওয়ার আগে গুরুত্বপূর্ণ দায়িত্ব',tag:'LEADERSHIP IN ACTION'},
 {start:900,end:1026,title:'২০২০ সালে',sub:'গ্রামীণফোনের সিইও হন',tag:'YASIR AZMAN • CEO SINCE 2020'},
];
const font = 'Noto Sans Bengali, Noto Sans, sans-serif';
export const YasirAzman: React.FC = () => {
 const f=useCurrentFrame(); const {durationInFrames}=useVideoConfig();
 const scene=scenes.find(s=>f>=s.start&&f<s.end)??scenes[scenes.length-1];
 const local=f-scene.start; const enter=interpolate(local,[0,18],[0,1],{extrapolateRight:'clamp'});
 const drift=interpolate(f,[0,durationInFrames],[0,28]);
 return <AbsoluteFill style={{background:'linear-gradient(115deg,#07122b 0%,#10294a 55%,#07152d 100%)',color:'#f8fbff',fontFamily:font,overflow:'hidden'}}>
  <AbsoluteFill style={{transform:`translate(${drift}px,0)`,opacity:.7}}>{Array.from({length:7}).map((_,i)=><div key={i} style={{position:'absolute',width:240+i*95,height:240+i*95,borderRadius:'50%',border:'2px solid rgba(35,204,225,.16)',right:-180-i*35,top:'50%',transform:'translateY(-50%)'}}/> )}</AbsoluteFill>
  <div style={{position:'absolute',left:105,top:88,padding:'13px 24px',border:'1px solid rgba(91,226,240,.5)',borderRadius:40,color:'#79e7ef',fontSize:22,letterSpacing:2,fontFamily:'Arial,sans-serif'}}>LEADERSHIP STORY</div>
  <div style={{position:'absolute',right:110,top:88,color:'#65dbe8',fontSize:26,fontWeight:700,fontFamily:'Arial,sans-serif'}}>{String(scenes.indexOf(scene)+1).padStart(2,'0')} / 07</div>
  <div style={{position:'absolute',left:118,top:330,width:8,height:285,borderRadius:8,background:'#00cddd',transform:`scaleY(${enter})`,transformOrigin:'top'}}/>
  <div style={{position:'absolute',left:170,top:330,right:240,opacity:enter,transform:`translateY(${(1-enter)*35}px)`}}>
   <div style={{fontSize:68,fontWeight:700,lineHeight:1.35,letterSpacing:-1}}>{scene.title}</div>
   <div style={{fontSize:43,color:'#65e1e9',marginTop:26,lineHeight:1.4}}>{scene.sub}</div>
   <div style={{height:2,width:760,background:'rgba(87,220,232,.5)',marginTop:42}}/>
   <div style={{fontFamily:'Arial,sans-serif',fontSize:23,letterSpacing:3,color:'#b2c7df',marginTop:24}}>{scene.tag}</div>
  </div>
  <div style={{position:'absolute',left:110,bottom:75,fontSize:19,letterSpacing:2,color:'#90a9c7',fontFamily:'Arial,sans-serif'}}>GRAMEENPHONE / EXECUTIVE PROFILE</div>
  <div style={{position:'absolute',right:110,bottom:82,width:340,height:8,background:'rgba(255,255,255,.13)',borderRadius:8,overflow:'hidden'}}><div style={{height:'100%',width:`${(f/durationInFrames)*100}%`,background:'#00cddd'}}/></div>
  <Audio src={staticFile('narration.mp3')} volume={1}/>
 </AbsoluteFill>;
};
