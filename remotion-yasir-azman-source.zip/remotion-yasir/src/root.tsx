import React from 'react';
import {Composition} from 'remotion';
import {YasirAzman} from './video';
export const Root: React.FC = () => <Composition id="YasirAzman" component={YasirAzman} durationInFrames={1026} fps={30} width={1920} height={1080} />;
