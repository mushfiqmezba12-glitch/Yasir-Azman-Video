# Yasir Azman — Remotion Motion Graphics

A 1920×1080, 30fps Remotion composition using the supplied Bengali narration. The composition is 34.2 seconds and uses timed scene cards, subtle signal-ring motion, animated text entrances, a progress indicator, and the original audio.

## Run

1. Install Node.js 18+.
2. Run `npm install`.
3. Run `npm run start` to preview in Remotion Studio.
4. Run `npm run render` to render `out/yasir-azman.mp4`.

The supplied audio is in `public/narration.mp3`. Ensure a Bengali-capable font is available on the render machine (e.g. Noto Sans Bengali). Scene copy follows the provided transcription; verify all biographical facts before public distribution.
